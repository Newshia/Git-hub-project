var c = 0;
let value = 0
function setup() {
  createCanvas(700, 700);
  colorMode(RGB,255,255,255);
  background(128,212,255);
  frameRate(30)
}

function draw() {
  
          if (keyIsPressed) {
  fill(255,255,255);
  ellipse(320, 420, 50, 50);
  line(320,447,320,500);
  line(320,500,350,530);
  line(320,500,300,530);
  line(320,450,350,480);
  line(320,450,290,480);
      }
  strokeWeight(5)
  stroke(0,0,0);
  fill(value);
  rect(230,390,210,175);
  
  stroke(53, 204, 71);
  fill(53, 204, 71);//green
  rect(0, 500, 700, 200);
  
  strokeJoin(BEVEL);
  strokeWeight(10);
  stroke(147, 106, 19);
  fill(147, 106, 19); //brown
  rect(220,380,270,200);
  
  strokeWeight(2);
  fill(0,0,0);
  ellipse(470,410,25,25);
  
  strokeWeight(2);
  fill(0,0,0);
  ellipse(470,450,25,25);
  
  strokeWeight(4);
  stroke(159, 159, 159);
  rect(455,480,30,80);
  
  stroke(0,0,0);
  line(250,300,340,375);
  
  stroke(0,0,0);
  line(440,300,340,375);
  
  strokeWeight(5)
  stroke(0,0,0);
  fill(value);
  rect(230,390,210,175);
  //this is to make stick man appear
  if (keyIsPressed) {
   (key="s")
  fill(255,255,255);
  ellipse(320, 420, 50, 50);
  line(320,447,320,500);
  line(320,500,350,530);
  line(320,500,300,530);
  line(320,450,350,480);
  line(320,450,290,480);
   }
  
for (var i = 10; i < 70; i += 6) {
  stroke(248, 160, 56);
  fill(246, 225, 17);
    rect(i, i, i , i);}
  
  //cloud moving
  c = c + 1;
  fill(255,255,255);
  stroke(255,255,255);
  ellipse(c+200,110,60,60);
  ellipse(c+250,110,60,60);
  ellipse(c+225,70,60,60);
  
}
function mousePressed() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
}