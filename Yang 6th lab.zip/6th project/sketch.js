function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(0);
  
  translate(250,250);
  strokeJoin(BEVEL);
  strokeWeight(4);
  fill(0);
stroke(4, 6, 243);
beginShape();
// outside square
vertex(-170, -40);
vertex(170, -40);
vertex(170, 90);
vertex(-170, 90);
// inside square
beginContour();
vertex(-155, -30);
vertex(-155, 80);
vertex(155, 80);
vertex(155, -30);
endContour();
endShape(CLOSE);

  //bottom line
  stroke(0);
line(-40,-30,50,-30);
  
  //top line
    stroke(0);
line(-40,-40,50,-40);
  
  //right side
    stroke(4, 6, 243);
line(50,-40,50,-30);
  
  //left side
      stroke(4, 6, 243);
line(-40,-40,-40,-30);
  
  //middle line
      stroke(250, 198, 108);
line(-35,-36,46,-36);
  
  ghost1(5,5);
  
  ghost2(200,0)
  
  ghost3(-100,0)
  
  ghost4(0,-130)

  for (var x = 30; x < width + 20; x += 55) {
		pellets(x, 110);
  
}

stroke(241, 208, 62);
  fill(241, 208, 62);
ellipse (115,5,15,15);
  scale(1);
stroke(241, 208, 62);
  fill(241, 208, 62);
ellipse (115,70,30,30);
  
  translate(0, 0);
  angleMode(RADIANS)
  rotate(HALF_PI / 2.0);
  arc(-250, 180, 80, 80, 6, PI + QUARTER_PI, PIE);
  
}
function ghost1(x,y){
  translate(x,y)
  // dark green ghost
  fill(12, 109, 1)
  stroke(12, 109, 1)
  rect(-130,20,50,30)
  
  fill(12, 109, 1)
  ellipse(-105,15,50,50)
  
  stroke(0)
  fill(0)
  triangle(-135, 60, -120, 40, -105, 60);
  
  stroke(0)
  fill(0)
  triangle(-110, 60, -90, 40, -80, 60);
  
  fill(255)
  stroke(255)
  ellipse(-119,15,15,15)
  
  fill(255)
  stroke(255)
  ellipse(-95,15,15,15)
  
  fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-100,15,5,5)
  
    fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-124,15,5,5)
  
}

function ghost2(x,y){
  translate(x,y)
  // lime green ghost
  fill(39, 243, 17 )
  stroke(39, 243, 17)
  rect(-130,20,50,30)
  
  fill(39, 243, 17 )
  ellipse(-105,15,50,50)
  
  stroke(0)
  fill(0)
  triangle(-135, 60, -120, 40, -105, 60);
  
  stroke(0)
  fill(0)
  triangle(-110, 60, -90, 40, -80, 60);
  
  fill(255)
  stroke(255)
  ellipse(-119,15,15,15)
  
  fill(255)
  stroke(255)
  ellipse(-95,15,15,15)
  
  fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-90,15,5,5)
  
    fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-115,15,5,5)
  
}

function ghost3(x,y){
  translate(x,y)
  // purple ghost
  fill(158, 17, 243)
  stroke(158, 17, 243)
  rect(-130,20,50,30)
  
  fill(158, 17, 243)
  ellipse(-105,15,50,50)
  
  stroke(0)
  fill(0)
  triangle(-135, 60, -120, 40, -105, 60);
  
  stroke(0)
  fill(0)
  triangle(-110, 60, -90, 40, -80, 60);
  
  fill(255)
  stroke(255)
  ellipse(-119,15,15,15)
  
  fill(255)
  stroke(255)
  ellipse(-95,15,15,15)
  
  fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-95,20,5,5)
  
    fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-119,20,5,5)
  
}

function ghost4(x,y){
  translate(x,y)
  // purple ghost
  fill(155, 0, 0 )
  stroke(155, 0, 0 )
  rect(-130,20,50,30)
  
  fill(155, 0, 0 )
  ellipse(-105,15,50,50)
  
  stroke(0)
  fill(0)
  triangle(-135, 60, -120, 40, -105, 60);
  
  stroke(0)
  fill(0)
  triangle(-110, 60, -90, 40, -80, 60);
  
  fill(255)
  stroke(255)
  ellipse(-119,15,15,15)
  
  fill(255)
  stroke(255)
  ellipse(-95,15,15,15)
  
  fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-95,11,5,5)
  
    fill(17, 43, 243)
  stroke(17, 43, 243)
  ellipse(-119,11,5,5)
  
}

function pellets(x, y) {

	push();

	translate(x, 10);

fill(241, 208, 62 )
stroke(241, 208, 62 )
ellipse(-300,-70,15,15)

	pop();
}