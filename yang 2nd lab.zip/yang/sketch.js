function setup() {
  createCanvas(400,400);
  background(230);
}

function draw() {
  colorMode(RGB, 225, 255, 255, 1);
  
  //Triangle x1, y1, x2, y2, x3, y3
  fill(153, 51, 255);
  stroke(255, 153, 0)
  strokeWeight(2);
  triangle(330, 167, 358, 140, 386, 155);
  
  //quad x1,y1,x2,y2,x3,y3,x4,y4
  fill(1, 1, 203);
  stroke(255, 213, 0);
  strokeWeight(3);
  quad(250, 180, 215, 80, 180, 187, 215, 147);
  
  //arc x, y, w, h, start, stop, mode, detail
  fill(240, 61, 61);
  strokeWeight(5);
  stroke('green')
  arc(50, 230, 130, 130, 0,HALF_PI);
  
  // curve vertex
  stroke('black');
  strokeWeight(5);
  point(215, 147);
  point(220, 190);
  point(250, 230);
  point(210, 260);
  strokeWeight(1);
  
  noFill();
  stroke('black');
  beginShape();
  curveVertex(215, 147);
  curveVertex(215, 147);
  curveVertex(220, 190);
  curveVertex(250, 230);
  curveVertex(210, 260);
  curveVertex(210, 260);
  endShape();
  
  fill(255, 102, 204);
  stroke(51, 102, 204);
  strokeWeight(3);
  ellipse(305, 300, 30, 30);

    fill(255, 102, 204);
  stroke(51, 102, 204);
  strokeWeight(3);
  ellipse(350, 270, 30, 30);
  
  strokeWeight(5);
  line(340, 260, 305, 285);
  
    strokeWeight(5);
  line(360, 280, 305, 315);
  
  stroke('black')
  strokeWeight(9)
  point(60, 255);
  
  strokeWeight(9)
  point(75, 240);
  
  strokeWeight(9)
  point(60, 280);
  
    strokeWeight(9)
  point(80, 265);
  
      strokeWeight(9)
  point(100, 245);
  
  strokeWeight(1)
  line(305,302,350,320);
  
    strokeWeight(1)
  line(350,270,350,320);
  
    strokeWeight(1)
  line(390,400,350,320);
  
    strokeWeight(1)
  line(330,167,356,200);
  
    strokeWeight(1)
  line(358,140,356,200);
  
      strokeWeight(1)
  line(386,155,356,200);
  
      strokeWeight(1)
  line(200,400,356,200);
  
        strokeWeight(1)
  line(116,230,150,300);
  
        strokeWeight(1)
  line(50,295,150,300);
  
       strokeWeight(1)
  line(300,400,150,300);
}
